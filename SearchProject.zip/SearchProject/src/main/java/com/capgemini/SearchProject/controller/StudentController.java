package com.capgemini.SearchProject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {
				
				@RequestMapping("/")
				public String searchForm() {
					return "search";
					
				}
				
				
}
