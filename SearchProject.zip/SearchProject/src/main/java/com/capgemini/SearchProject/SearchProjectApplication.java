package com.capgemini.SearchProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchProjectApplication.class, args);
	}
}
