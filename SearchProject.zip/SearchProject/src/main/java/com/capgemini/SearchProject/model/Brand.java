package com.capgemini.SearchProject.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Brand {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int brandId;
private String brandName;
@OneToMany(targetEntity=Inventory.class, mappedBy="brand")
private Inventory inventory;

public Brand() {
	super();
}

public Brand(int brandId, String brandName, Inventory inventory) {
	super();
	this.brandId = brandId;
	this.brandName = brandName;
	this.inventory = inventory;
}

public int getBrandId() {
	return brandId;
}

public void setBrandId(int brandId) {
	this.brandId = brandId;
}

public String getBrandName() {
	return brandName;
}

public void setBrandName(String brandName) {
	this.brandName = brandName;
}

public Inventory getInventory() {
	return inventory;
}

public void setInventory(Inventory inventory) {
	this.inventory = inventory;
}


}
